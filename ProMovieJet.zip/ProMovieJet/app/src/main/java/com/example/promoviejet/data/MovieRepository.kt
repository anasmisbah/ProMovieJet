package com.example.promoviejet.data

import androidx.lifecycle.LiveData
import com.example.promoviejet.data.local.entity.Movie
import com.example.promoviejet.data.local.entity.TvShow
import com.example.promoviejet.data.remote.RemoteRepository

class MovieRepository(private val remoteRepository: RemoteRepository) : MovieDataSource{

    companion object{
        private var  INSTANCE : MovieRepository? = null
        fun getInstance(remoteRepository: RemoteRepository): MovieRepository{
            if (INSTANCE == null){
                synchronized(MovieRepository::class.java){
                    INSTANCE = MovieRepository(remoteRepository)
                }
            }
            return INSTANCE!!
        }
    }

    override fun getMovie(apiKey: String): LiveData<List<Movie>> {
        return remoteRepository.getMovieNowPlaying(apiKey)
    }

    override fun getTvShow(apiKey: String): LiveData<List<TvShow>> {
        return remoteRepository.getTvShow(apiKey)
    }

    override fun getDetailMovie(id: String, apiKey: String): LiveData<Movie> {
        return remoteRepository.getDetailMovie(id,apiKey)
    }

    override fun getDetailTvShow(id: String, apiKey: String): LiveData<TvShow> {
        return remoteRepository.getDetailTvShow(id,apiKey)
    }

}