package com.example.promoviejet.data

import androidx.lifecycle.LiveData
import com.example.promoviejet.data.local.entity.Movie
import com.example.promoviejet.data.local.entity.TvShow

interface MovieDataSource {

    //untuk halaman movie
    fun getMovie(apiKey:String) : LiveData<List<Movie>>

    //untuk halaman tvshow
    fun getTvShow(apiKey:String) : LiveData<List<TvShow>>

    //untuk detail movie
    fun getDetailMovie(id:String,apiKey: String): LiveData<Movie>

    //untuk detail tvshow
    fun getDetailTvShow(id:String,apiKey: String) : LiveData<TvShow>

}