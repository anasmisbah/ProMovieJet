package com.example.promoviejet.di

import android.app.Application
import com.example.promoviejet.data.MovieRepository
import com.example.promoviejet.data.remote.RemoteRepository

class Injection {
    companion object{
        fun provideRepository(application: Application) : MovieRepository{
            val remoteRepository = RemoteRepository.getInstance()

            return MovieRepository.getInstance(remoteRepository)
        }
    }
}