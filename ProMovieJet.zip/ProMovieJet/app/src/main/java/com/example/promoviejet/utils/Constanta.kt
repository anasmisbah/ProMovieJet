package com.example.promoviejet.utils

const val EXTRA_MOVIE = "extra_movie"
const val EXTRA_TVSHOW = "extra_tvshow"

const val ENDPOINT_GET_MOVIE_NOW_PLAYING = "movie/now_playing"
const val ENDPOINT_GET_TV_SHOW = "tv/airing_today"
const val ENDPOINT_DETAIL_MOVIE = "movie/"
const val ENDPOINT_DETAIL_TV_SHOW = "tv/"