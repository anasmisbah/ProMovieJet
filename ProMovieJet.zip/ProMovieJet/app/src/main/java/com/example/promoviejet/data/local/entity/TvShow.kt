package com.example.promoviejet.data.local.entity

data class TvShow(
 val id:String,
     val title :String,
 val voteAverage :String,
 val language :String,
 val overview :String,
 val releaseDate :String,
 val poster :String,
 val backDrop: String? = null
)